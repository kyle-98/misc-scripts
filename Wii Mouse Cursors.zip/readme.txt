--- pack created by @fanta_ferret ---

Wii Cursors is a faithful recreation of the onscreen Wiimote pointer for use as a cursor scheme!

This pack is created for use on computers running Windows.

I've seen multiple attempts at a Wii cursor scheme before, but none of them were good enough quality
or accurate enough for my tastes. So, I've decided to recreate the original Wii sprites in vector form
to get the perfect scale for a cursor!

"Background" and "Busy" are animated


--- How to install ... ---

1. Extract "Wii Cursors" folder from .zip and place it somewhere on your computer
2. Start/Search > "Change how the mouse pointer looks"
3. Select a cursor then press "Browse..."
4. Locate the "Wii Cursors" folder and select the respective cursor file
5. Repeat until all cursors are linked
6. Under "Scheme", press "Save As...", then save it as "Wii"
7. Apply > OK
8. Done!

--- pack created by @fanta_ferret ---

please don't reupload without my permission...